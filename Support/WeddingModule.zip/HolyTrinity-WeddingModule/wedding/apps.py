from django.apps import AppConfig


class WeddingConfig(AppConfig):
    name = 'wedding'
