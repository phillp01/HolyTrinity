from django.apps import AppConfig


class CreatesuperuserConfig(AppConfig):
    name = 'createsuperuser'
